"""
PFC Circuit Model: 4-Population Rate Model with Parameter Optimization.

This package implements a computational model of the prefrontal cortex (PFC)
microcircuit with 4 neural populations:
- PYR: Pyramidal cells (excitatory)
- PV: Parvalbumin interneurons (fast-spiking inhibitory)
- SOM: Somatostatin interneurons (inhibitory, dendritic targeting)
- VIP: VIP interneurons (inhibitory, disinhibitory)

The model uses the Wong-Wang transfer function and supports:
- Nevergrad-based parameter optimization
- Nicotinic receptor knockout simulations (alpha7, alpha5, beta2)
- Multiple noise types (white, Ornstein-Uhlenbeck)

Usage:
    # As a library
    from circuit_model import CircuitParams, simulate_circuit, mean_rates

    params = CircuitParams()
    result = simulate_circuit(params, T_ms=1000)
    rates = mean_rates(result, burn_in_ms=500, window_ms=500)

    # From command line
    python -m circuit_model --target_pyr 5 --target_som 10 --target_pv 15 --target_vip 8
"""

from .params import CircuitParams, ParamBound, default_bounds
from .transfer import phi_wong_wang
from .simulation import SimulationResult, simulate_circuit, mean_rates, NoiseType
from .loss import TargetRates, FitConfig, loss_from_means, loss_from_ko_pyr
from .optimization import (
    KOMeans,
    Candidate,
    run_trials,
    evaluate_params,
    build_nevergrad_parametrization,
    params_from_ng_dict,
    nevergrad_optimize,
)
from .io import load_params_json, save_params_json, format_params_as_code, log_best_result
from .plotting import (
    plot_firing_rates,
    plot_adaptation,
    plot_simulation_dashboard,
    plot_mean_rates_bar,
    print_simulation_summary,
    POPULATION_NAMES,
    POPULATION_COLORS,
)
from .cli import main

__all__ = [
    # Parameters
    "CircuitParams",
    "ParamBound",
    "default_bounds",
    # Transfer function
    "phi_wong_wang",
    # Simulation
    "SimulationResult",
    "simulate_circuit",
    "mean_rates",
    "NoiseType",
    # Loss/targets
    "TargetRates",
    "FitConfig",
    "loss_from_means",
    "loss_from_ko_pyr",
    # Optimization
    "KOMeans",
    "Candidate",
    "run_trials",
    "evaluate_params",
    "build_nevergrad_parametrization",
    "params_from_ng_dict",
    "nevergrad_optimize",
    # I/O
    "load_params_json",
    "save_params_json",
    "format_params_as_code",
    "log_best_result",
    # Plotting
    "plot_firing_rates",
    "plot_adaptation",
    "plot_simulation_dashboard",
    "plot_mean_rates_bar",
    "print_simulation_summary",
    "POPULATION_NAMES",
    "POPULATION_COLORS",
    # CLI
    "main",
]
